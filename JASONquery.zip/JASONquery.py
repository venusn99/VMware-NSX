import json
#pip install xlwt 
import xlwt
from xlwt import Workbook


# Workbook is created
wb = Workbook()
  
# add_sheet is used to create sheet.
sheet1 = wb.add_sheet('Sheet 1')
sheet1.write(0, 0, "RULE NAME")
sheet1.write(0, 1, "SOURCE Group")
sheet1.write(0, 2, "SOURCE IP/VM")
sheet1.write(0, 3, "DESTINATION Group")
sheet1.write(0, 4, "DESTINATION IP/VM")
sheet1.write(0, 5, "SERVICE")


#read the JSON
JSON_file = open("recommendations2.json")  #change file names
JSON_input = json.load(JSON_file)
JSON_file.close()


#sort the domain child element
temp = JSON_input["children"][0]["Domain"]["children"]
rules = {}
groups = {}

for i in temp:
    if i["resource_type"] == "ChildSecurityPolicy":
        rules = i["SecurityPolicy"]["children"]
    else:
        groups[i["Group"]["id"]] = {
            "display_name": i["Group"]["display_name"],
            #"ip_addresses": i["Group"]["expression"] 
            }
        temp_ips = i["Group"]["expression"]
        for temp_ip in temp_ips:
            if temp_ip["resource_type"] == "ExternalIDExpression":
                groups[i["Group"]["id"]]["Virtual_Machine"] = temp_ip["external_ids"]
            elif temp_ip["resource_type"] == "IPAddressExpression":
                groups[i["Group"]["id"]]["ip_addresses"] = temp_ip["ip_addresses"]


#genrate output in py
"""for rule in rules:
    print("RULE NAME:",rule["Rule"]["display_name"])
    print("Source Group:",rule["Rule"]["source_groups"])
    print("Destination Group:",rule["Rule"]["destination_groups"])
    print("Services:",rule["Rule"]["services"])
    print("---------------------------------------------------")"""


#print(groups)



#services
services = {}
temp = JSON_input["children"][1:]
for i in temp:
    if i["resource_type"] == "ChildService":
        services[i["Service"]["id"]] = i["Service"]["display_name"]



row = 2
#dict
for rule in rules:
    nxt_row = row
    #Rule Name
    rule_name = rule["Rule"]["display_name"]
    sheet1.write(row, 0, rule_name)
    
    #Source
    x1=row
    x2=row
    source_name = []
    source = []
    temp_sources = rule["Rule"]["source_groups"]
    for temp_source in temp_sources:
        temp_s = temp_source.split("/")
        temp_s = temp_s[-1]
        try:
            source_keys = groups[temp_s].keys()
            for source_key in source_keys:
                if source_key == "display_name":
                    source_name += [groups[temp_s][source_key]]
                    sheet1.write(x1, 1, groups[temp_s][source_key])
                    x1+=1
                else:
                    source += groups[temp_s][source_key]
                    for i in groups[temp_s][source_key]:
                        sheet1.write(x2, 2, i)
                        x2+=1
        except:
            source_name += [temp_s]
            sheet1.write(x1, 1, temp_s)
            x1+=1
            if x1>nxt_row:
                nxt_row = x1
            source += [temp_s]
            sheet1.write(x2, 2, temp_s)
            x2+=1

    if x1>nxt_row:
        nxt_row = x1
    if x2>nxt_row:
        nxt_row = x2
    

            
    #destination
    x1=row
    x2=row
    destination_name = []
    destination = []
    temp_destinations = rule["Rule"]["destination_groups"]
    for temp_destination in temp_destinations:
        temp_d = temp_destination.split("/")
        temp_d = temp_d[-1]
        try:
            destination_keys = groups[temp_d].keys()
            for destination_key in destination_keys:
                if destination_key == "display_name":
                    destination_name += [groups[temp_d][destination_key]]
                    sheet1.write(x1, 3, groups[temp_d][destination_key])
                    x1+=1
                else:
                    destination += groups[temp_d][destination_key]
                    for i in groups[temp_d][destination_key]:
                        sheet1.write(x2, 4, i)
                        x2+=1
        except:
            destination_name += [temp_d]
            sheet1.write(x1, 3, temp_d)
            x1+=1
            destination += [temp_d]
            sheet1.write(x2, 4, temp_d)
            x2+=1

    if x1>nxt_row:
        nxt_row = x1
    if x2>nxt_row:
        nxt_row = x2


        
    #service
    x1 = row
    service = []
    temp_services = rule["Rule"]["services"]
    for temp_service in temp_services:
        temp_sv = temp_service.split("/")
        temp_sv = temp_sv[-1]
        try:
            service += [services[temp_sv]]
            sheet1.write(x1, 5, services[temp_sv])
            x1+=1
        except:
            service += [temp_sv]
            sheet1.write(x1, 5, temp_sv)
            x1+=1
    if x1>nxt_row:
        nxt_row = x1

    row = nxt_row+1



#output file
wb.save('xlwt example2.xls')    #change file names





    
